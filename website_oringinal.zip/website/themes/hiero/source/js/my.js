/*
type your custom JavaScript here
在本文件中键入您的自定义JS脚本
升级主题文件时请注意保护本文件，防止意外覆盖。
*/